
MuSHR - v8 MuSHR3
==============================

This dataset was exported via roboflow.ai on July 11, 2021 at 3:38 PM GMT

It includes 803 images.
MuSHR-cars are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Fit (black edges))

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Random rotation of between -20 and +20 degrees
* Random brigthness adjustment of between -44 and +44 percent
* Random Gaussian blur of between 0 and 1 pixels


